import React from 'react';
import SmartDeductionFinder from './components/SmartDeductionFinder';

function App() {
  return <SmartDeductionFinder />;
}

export default App;