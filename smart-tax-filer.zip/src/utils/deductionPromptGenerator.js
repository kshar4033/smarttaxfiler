export function generatePrompt(user) {
  return `Suggest deductions for age ${user.age}, income ₹${user.income}`;
}