export const getMockDeductions = () => [
  { section: '80C', label: 'LIC Premium', amount: 12000 },
  { section: '80E', label: 'Education Loan Interest', amount: 40000 },
];