import React from 'react';
export default function LandingPage() { return <h1>Welcome to Smart Tax Filer</h1>; }